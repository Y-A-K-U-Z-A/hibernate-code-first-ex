package homework.footballbetting;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Table(name = "players")
@NoArgsConstructor
public class Player extends BaseEntity {
    @Getter @Setter @Column(name = "name")
    private String name;
    @Getter @Setter @Column(name = "squad_number")
    private int squadNumber;
    @Getter @Setter @ManyToOne @JoinColumn(name = "team_id", referencedColumnName = "id")
    private Team team;
    @Getter @Setter @OneToOne @JoinColumn(name = "position_id", referencedColumnName = "id")
    private Position position;
    @Getter @Setter @Column(name = "is_currently_injured")
    private boolean isCurrentlyInjured;

}
