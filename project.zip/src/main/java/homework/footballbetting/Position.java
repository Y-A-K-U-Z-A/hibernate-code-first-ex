package homework.footballbetting;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "positions")
@NoArgsConstructor
public class Position {
    @Getter @Setter @Id @Column(name = "id", length = 2)
    private String id;
    @Getter @Setter @Column(name = "position_description")
    private String positionDescription;
}
