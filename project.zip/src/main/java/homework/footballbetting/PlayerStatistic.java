//package homework.footballbetting;
//
//import javax.persistence.Entity;
//import javax.persistence.Table;
//
//@Entity
//@Table(name = "player_statistics")
//public class PlayerStatistic extends BaseEntity{
////    private Game game;
//    private Player player;
//    private int scoredGoals;
//    private Player playerAssist;
//    private double playedMinutesDuringGame;
//
////    //
////    PlayerStatistics – Game, Player, Scored Goals, Player Assists, Played Minutes During Game, (PK = Game + Player)
//
//}
