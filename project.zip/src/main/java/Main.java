import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.Scanner;

public class Main {
    private static final Scanner sc = new Scanner(System.in);

    private static final String PU_GRINGOTTS_NAME = "gringotts";
    private static final String PU_SALES_NAME = "sales";
    private static final String PU_UNIVERSITY_NAME = "university";
    private static final String PU_HOSPITAL_NAME = "hospital";
    private static final String PU_BILLPAYMENT_NAME = "billpayment";
    private static final String PU_FOOTBALLBETTING_NAME = "footballbetting";

    private static EntityManagerFactory emf;

    public static void main(String[] args) {
        printOut();
    }

    private static void printOut() {
        System.out.println("Welcome!");
        System.out.println("Before starting you must: ");
        System.out.println("\t- make sure you have clean Database");
        System.out.println("\t- change persistence unit name in persistence.xml file with the proper name.");
        System.out.println();
        System.out.println("For creating Gringotts database please press 1");
        System.out.println("For creating Sales database please press 2");
        System.out.println("For creating University system please press 3");
        System.out.println("For creating Hospital database please press 4");
        System.out.println("For creating Bill Payment system please press 5");
        System.out.println("For creating Football Betting database please press 6");
        String input = sc.nextLine();
        switch (input){
            case "1":
                emf = Persistence.createEntityManagerFactory(PU_GRINGOTTS_NAME);
                emf.createEntityManager();
                break;
            case "2":
                emf = Persistence.createEntityManagerFactory(PU_SALES_NAME);
                emf.createEntityManager();
                break;
            case "3":
                emf = Persistence.createEntityManagerFactory(PU_UNIVERSITY_NAME);
                emf.createEntityManager();
                break;
            case "4":
                emf = Persistence.createEntityManagerFactory(PU_HOSPITAL_NAME);
                emf.createEntityManager();
                break;
            case "5":
                emf = Persistence.createEntityManagerFactory(PU_BILLPAYMENT_NAME);
                emf.createEntityManager();
                break;
            case "6":
                emf = Persistence.createEntityManagerFactory(PU_FOOTBALLBETTING_NAME);
                emf.createEntityManager();
                break;
        }
    }
}
