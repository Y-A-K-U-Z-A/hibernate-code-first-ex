package homework.hospital;

import javax.persistence.*;
import java.util.Set;

@Entity
@Table(name = "diagnoses")
public class Diagnose extends BaseEntity{
    private String name;
    private String comments;
    private Set<Medicaments> medicaments;

    public Diagnose(){}

    @Column(name = "name")
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    @Column(name = "comments")
    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    @OneToMany
    @JoinColumn(name = "medicament_id", referencedColumnName = "id")
    public Set<Medicaments> getMedicaments() {
        return medicaments;
    }

    public void setMedicaments(Set<Medicaments> medicaments) {
        this.medicaments = medicaments;
    }
}
